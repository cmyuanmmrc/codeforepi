
Input: SHY[3]; Ru[i],i=1..8; R[j], j=1..955;

Output: ffp; ggp;

Contrast with the paper, we have
SHY3[1] is F[3,a,b,c] in Section 4.2;
Ru[i] is R[i]^{(0)} in Section 4.2.1;
R[j] corresponds to R[j,a,b,c]^{(3)} in Section 4.2.1.

Note that the number of constraints given here is the number after removing the repeated ones.

After running the program, if ffp=0, then the SOS representation of F[3,2] can be obtained. And ``ggp'' is exactly the SOS representation.