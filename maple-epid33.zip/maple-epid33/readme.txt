
Input: SHY[3]; R[i],i=1..955; Ru[j],j=1..8; Rz[k], k=1..25;

Output: ffp; ggp;

Contrast with the paper, we have:
SHY3[1] is F[3,a,b,c] in Section 4.2;
R[i] corresponds to R[i,a,b,c]^{(3)} in Section 4.2.2;
Ru[j] corresponds to R[j]^{(0)} in Section 4.2.2;
Rz[k] correponds to R[k,a,b]^{(2)} in Section 4.2.2. 

Note that the number of constraints given here is the number after removing the repeated ones.

After running the program, if ffp=0, then the SOS representation of F[3,3] can be obtained. And ``ggp'' is exactly the SOS representation.
